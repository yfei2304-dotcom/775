# ModI18N 繁體中文（台灣）改作版

本模組以 Degrees of Lewdity 中文漢化社群的 `ModI18N-0.5.12.11-chs-auto-nightly` 為基礎，使用 OpenCC `s2twp` 規則轉換為繁體中文並調整模組版本資訊。

- 原始漢化專案：https://github.com/Eltirosto/Degrees-of-Lewdity-Chinese-Localization
- 原始構建來源：https://github.com/NumberSir/DoL-I18n-Build/releases/download/0.5.12.11-chs-auto-nightly-auto--d230276d3f0390986e385a5b924c286769bcab1a/ModI18N-0.5.12.11-chs-auto-nightly.mod.zip
- 修改內容：簡體中文字詞轉為繁體中文（台灣慣用詞），英文來源欄位、Twine 巨集、程式識別字與依賴版本保持不變。
- 授權：CC BY-NC-SA 4.0（署名－非商業性－相同方式分享）
- 授權全文：https://github.com/Eltirosto/Degrees-of-Lewdity-Chinese-Localization/blob/main/LICENSE
- 狀態：非漢化組官方發行版；不代表原漢化組背書。
